<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085100337             |
    |_______________________________________|
*/
 use Pmpr\Module\TabbedProfile\TabbedProfile; TabbedProfile::symcgieuakksimmu();
