<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b62235b5             |
    |_______________________________________|
*/
 use Pmpr\Module\TabbedProfile\TabbedProfile; TabbedProfile::symcgieuakksimmu();
