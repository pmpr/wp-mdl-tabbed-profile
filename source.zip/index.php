<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106ae14706             |
    |_______________________________________|
*/
 use Pmpr\Module\TabbedProfile\TabbedProfile; TabbedProfile::symcgieuakksimmu();
