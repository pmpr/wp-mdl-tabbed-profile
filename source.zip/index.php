<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11cf794d9             |
    |_______________________________________|
*/
 use Pmpr\Module\TabbedProfile\TabbedProfile; TabbedProfile::symcgieuakksimmu();
