<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4258d45ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\ComponentInitiator; class TabbedProfile extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x54\141\142\142\145\144\x20\x50\162\x6f\x66\151\x6c\145", PR__MDL__TABBED_PROFILE); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\x5f\x69\x6e\x69\164", [$this, "\145\156\161\x75\x65\x75\145"]); parent::wigskegsqequoeks(); } public function enqueue() { if (!$this->caokeucsksukesyo()->issssuygyewuaswa()->eoyueosccuoeqkee()) { goto cecuyayqoioasumi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\x6d\151\156", $eygsasmqycagyayw->get("\141\x64\155\x69\156\x2e\x6a\x73"))); $eygsasmqycagyayw->ikqyiskqaaymscgw("\145\x78\x74\162\x61", [self::gouqcwikiiygyasc => "\155\151\x73\x63\145\154\x6c\141\156\145\x6f\x75\x73", self::qescuiwgsyuikume => __("\115\x69\x73\143\145\x6c\x6c\x61\156\x65\157\165\163", PR__MDL__TABBED_PROFILE)]); cecuyayqoioasumi: } }
