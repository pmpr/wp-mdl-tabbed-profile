<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c91c5c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\ComponentInitiator; class TabbedProfile extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x54\141\x62\x62\x65\144\x20\120\162\x6f\x66\151\x6c\x65", PR__MDL__TABBED_PROFILE); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\x69\x6e\x5f\x69\x6e\x69\164", [$this, "\x65\156\x71\x75\145\x75\145"]); parent::wigskegsqequoeks(); } public function enqueue() { if (!$this->caokeucsksukesyo()->issssuygyewuaswa()->eoyueosccuoeqkee()) { goto cecuyayqoioasumi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\x64\155\151\156", $eygsasmqycagyayw->get("\141\144\x6d\x69\x6e\x2e\152\x73"))); $eygsasmqycagyayw->ikqyiskqaaymscgw("\145\170\164\162\141", [self::gouqcwikiiygyasc => "\155\x69\x73\x63\145\x6c\154\141\156\x65\157\165\163", self::qescuiwgsyuikume => __("\x4d\151\x73\x63\x65\x6c\154\141\x6e\145\157\165\x73", PR__MDL__TABBED_PROFILE)]); cecuyayqoioasumi: } }
