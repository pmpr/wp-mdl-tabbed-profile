<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684011d44b35             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\ComponentInitiator; class TabbedProfile extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\124\141\x62\x62\x65\x64\40\120\x72\157\x66\x69\154\x65", PR__MDL__TABBED_PROFILE); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\x6e\x5f\x69\x6e\151\x74", [$this, "\x65\x6e\x71\x75\x65\x75\145"]); parent::wigskegsqequoeks(); } public function enqueue() { if (!$this->caokeucsksukesyo()->issssuygyewuaswa()->eoyueosccuoeqkee()) { goto cecuyayqoioasumi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x61\144\x6d\151\x6e", $eygsasmqycagyayw->get("\141\x64\155\x69\x6e\56\x6a\x73"))); $eygsasmqycagyayw->ikqyiskqaaymscgw("\145\170\x74\162\x61", [self::gouqcwikiiygyasc => "\x6d\x69\163\143\145\154\x6c\x61\x6e\145\x6f\x75\163", self::qescuiwgsyuikume => __("\x4d\x69\163\x63\x65\154\x6c\x61\156\x65\x6f\x75\163", PR__MDL__TABBED_PROFILE)]); cecuyayqoioasumi: } }
