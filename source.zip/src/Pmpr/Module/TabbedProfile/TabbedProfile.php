<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606ac3ba13a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\ComponentInitiator; class TabbedProfile extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\124\x61\x62\142\x65\144\x20\x50\162\x6f\x66\x69\154\x65", PR__MDL__TABBED_PROFILE); }, self::wuowaiyouwecckaw => false]); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\x6d\x69\156\x5f\151\156\x69\164", [$this, "\145\156\161\165\145\x75\145"]); parent::wigskegsqequoeks(); } public function enqueue() { if (!$this->caokeucsksukesyo()->issssuygyewuaswa()->eoyueosccuoeqkee()) { goto cecuyayqoioasumi; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\141\144\x6d\151\x6e", $eygsasmqycagyayw->get("\x61\144\155\151\156\x2e\152\163"))); $eygsasmqycagyayw->ikqyiskqaaymscgw("\145\x78\164\162\x61", [self::gouqcwikiiygyasc => "\155\151\163\143\x65\154\154\x61\x6e\x65\157\x75\163", self::qescuiwgsyuikume => __("\115\151\x73\x63\145\x6c\x6c\x61\156\145\x6f\165\163", PR__MDL__TABBED_PROFILE)]); cecuyayqoioasumi: } }
