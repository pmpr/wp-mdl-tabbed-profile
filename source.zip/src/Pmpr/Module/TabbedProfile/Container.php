<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606ac3ba13a2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
