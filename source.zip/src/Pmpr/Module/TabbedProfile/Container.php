<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b62235b5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\TabbedProfile; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
